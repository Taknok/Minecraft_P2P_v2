import time


if __name__ == "__main__":
    from generaux import *
    from apiclient.http import MediaFileUpload
else:
    from .generaux import *
    from .apiclient.http import MediaFileUpload


def Upload(path_file,title,exception = False):
    print("Debut de l'upload...")
    
    while upload_in_course() and not exception: #si le drive est en cour d'édition on attend
        time.sleep(5)
    
    
    FILENAME = path_file
    
    credentials = credentials_creator()

    drive_service = build_service(credentials)
    

    # Use 'drive_service' for all of the API calls
    # Insert a file
    media_body = MediaFileUpload(FILENAME, mimetype='text/plain', resumable=True)
    body = {
      'title': title,
      'mimeType': 'text/plain'
    }
    
    drive_service.files().insert(body=body, media_body=media_body).execute()
    
    
    print("Upload Fini !")

if __name__ == "__main__":
    import os,pdb
    Upload(os.path.dirname(os.path.abspath(__file__)) + '\\document_test.txt', 'Fichier test')
    