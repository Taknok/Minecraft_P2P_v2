from .generaux import *
from .Delete import *
from .Upload import *
from .Download import *